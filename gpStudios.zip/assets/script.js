
// gpStudios global script: theme, admin, video storage (YouTube + local with IndexedDB)

const ADMIN_PASSWORD = "Goutam@93324";
const DB_NAME = "gpstudios-db";
const STORE = "videos";

// Theme
function setTheme(t){
  document.body.setAttribute('data-theme', t);
  localStorage.setItem('gp_theme', t);
}
const savedTheme = localStorage.getItem('gp_theme') || 'light';
setTheme(savedTheme);

// Navbar actions
function go(p){ location.href = p; }

// IndexedDB helpers for storing local video blobs
function openDB(){
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = e => {
      const db = e.target.result;
      if(!db.objectStoreNames.contains(STORE)){
        db.createObjectStore(STORE, {keyPath: 'id'});
      }
    };
    r.onsuccess = e => res(e.target.result);
    r.onerror = e => rej(e.target.error);
  });
}

async function saveLocalVideo(id, name, blob){
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, 'readwrite');
    const s = tx.objectStore(STORE);
    s.put({id, name, blob});
    tx.oncomplete = () => res(true);
    tx.onerror = e => rej(e.target.error);
  });
}

async function getLocalVideo(id){
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE,'readonly');
    const s = tx.objectStore(STORE);
    const rq = s.get(id);
    rq.onsuccess = e => res(e.target.result ? e.target.result.blob : null);
    rq.onerror = e => rej(e.target.error);
  });
}

async function deleteLocalVideo(id){
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE,'readwrite');
    const s = tx.objectStore(STORE);
    s.delete(id);
    tx.oncomplete = () => res(true);
    tx.onerror = e => rej(e.target.error);
  });
}

// Video state kept in localStorage as list of metadata
function loadVideoMeta(){
  return JSON.parse(localStorage.getItem('gp_videos_meta') || '[]');
}
function saveVideoMeta(arr){ localStorage.setItem('gp_videos_meta', JSON.stringify(arr)); }

// Render gallery (works for YouTube and local)
async function renderGallery(containerId='gallery'){
  const meta = loadVideoMeta();
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  for(const item of meta){
    const card = document.createElement('div');
    card.className = 'card fade-in';
    if(item.type === 'youtube'){
      const iframe = document.createElement('iframe');
      iframe.src = 'https://www.youtube.com/embed/' + item.id + '?rel=0';
      iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
      iframe.loading = 'lazy';
      card.appendChild(iframe);
    } else if(item.type === 'local'){
      const blob = await getLocalVideo(item.id);
      const url = blob ? URL.createObjectURL(blob) : null;
      const video = document.createElement('video');
      video.controls = true;
      video.preload = 'metadata';
      if(url) video.src = url;
      card.appendChild(video);
    }
    const h = document.createElement('h4'); h.textContent = item.title || (item.type==='youtube' ? 'YouTube Video' : item.name || 'Local Video');
    const p = document.createElement('p'); p.textContent = (item.type === 'youtube' ? 'YouTube' : 'Local file') + ' — uploaded by gp Studios';
    card.appendChild(h); card.appendChild(p);

    // double-click to delete (only admin)
    card.addEventListener('dblclick', async ()=>{
      if(sessionStorage.getItem('gp_admin') !== 'true'){ alert('Admin only: log in to delete.'); return; }
      if(!confirm('Delete this video?')) return;
      // remove metadata and local blob if needed
      const current = loadVideoMeta();
      const idx = current.findIndex(v=>v.key===item.key);
      if(idx>=0){
        if(item.type==='local') await deleteLocalVideo(item.id);
        current.splice(idx,1);
        saveVideoMeta(current);
        renderGallery(containerId);
      }
    });

    container.appendChild(card);
  }
}

// Helpers to parse YouTube IDs
function parseYouTubeId(url){
  try{
    const u = new URL(url);
    if(u.hostname.includes('youtu.be')) return u.pathname.slice(1);
    if(u.searchParams.get('v')) return u.searchParams.get('v');
    const parts = u.pathname.split('/').filter(Boolean);
    return parts.pop() || null;
  }catch(e){ return null; }
}

// Admin flow for videos.html
function initVideoPage(){
  const loginBtn = document.getElementById('loginBtn');
  const adminPanel = document.getElementById('adminPanel');
  const logoutBtn = document.getElementById('logoutBtn');
  const addYouTubeBtn = document.getElementById('addYouTube');
  const ytInput = document.getElementById('ytUrl');
  const ytTitle = document.getElementById('ytTitle');
  const addLocalInput = document.getElementById('localFile');
  const addLocalBtn = document.getElementById('addLocalBtn');

  function showAdmin(show){
    if(show) adminPanel.style.display = 'flex'; else adminPanel.style.display = 'none';
  }
  showAdmin(sessionStorage.getItem('gp_admin') === 'true');

  loginBtn.addEventListener('click', ()=>{
    if(sessionStorage.getItem('gp_admin') === 'true'){ alert('Already logged in'); return; }
    const pwd = prompt('Enter admin password:');
    if(pwd===ADMIN_PASSWORD){ sessionStorage.setItem('gp_admin','true'); showAdmin(true); alert('Admin unlocked'); }
    else alert('Incorrect password');
  });
  logoutBtn.addEventListener('click', ()=>{ sessionStorage.removeItem('gp_admin'); showAdmin(false); alert('Logged out'); });

  addYouTubeBtn.addEventListener('click', ()=>{
    if(sessionStorage.getItem('gp_admin') !== 'true'){ alert('Admin only'); return; }
    const url = ytInput.value.trim(); if(!url){ alert('Paste YouTube URL'); return; }
    const id = parseYouTubeId(url); if(!id){ alert('Bad YouTube URL'); return; }
    const meta = loadVideoMeta();
    const entry = { type:'youtube', id, key:'yt_'+Date.now(), title: ytTitle.value.trim() || '' };
    meta.unshift(entry); saveVideoMeta(meta); renderGallery();
    ytInput.value=''; ytTitle.value='';
  });

  addLocalBtn.addEventListener('click', async ()=>{
    if(sessionStorage.getItem('gp_admin') !== 'true'){ alert('Admin only'); return; }
    const files = addLocalInput.files;
    if(!files || files.length===0){ alert('Select a local video file (mp4)'); return; }
    const f = files[0];
    const id = 'local_'+Date.now();
    // store blob in IndexedDB
    await saveLocalVideo(id, f.name, f);
    const meta = loadVideoMeta();
    meta.unshift({ type:'local', id, key:id, name: f.name, title: f.name });
    saveVideoMeta(meta);
    addLocalInput.value = '';
    renderGallery();
  });

  // initial render
  renderGallery();
}

// On page load, if there is a gallery element, init video page handlers
document.addEventListener('DOMContentLoaded', ()=>{
  // theme switcher (if exists)
  const themeToggle = document.getElementById('themeToggle');
  if(themeToggle){
    themeToggle.checked = (localStorage.getItem('gp_theme')==='dark');
    themeToggle.addEventListener('change', ()=>{
      setTheme(themeToggle.checked ? 'dark' : 'light');
    });
  }
  if(document.getElementById('gallery')) initVideoPage();
});
