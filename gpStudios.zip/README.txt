gp Studios - Static portfolio site ready for GitHub Pages

Deploy: create repo gpstudios.github.io and upload files.